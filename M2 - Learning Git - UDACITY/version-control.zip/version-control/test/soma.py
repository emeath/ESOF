a = 1
b = 2.42123
c = a + b

print a, c, b